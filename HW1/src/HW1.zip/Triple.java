
public class Triple {
	
	public int n,r,v;
	
	public Triple(int n, int r, int v){
		this.n = n;
		this.r = r;
		this.v = v;
		
	}

}
