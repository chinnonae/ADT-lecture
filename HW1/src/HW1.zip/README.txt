Problem 1: Rec.java
	This class contain lots of recursive methods each one do a specific task, such as
	counting number of a character in string.
	
Problem 2: PermuteK.java
	This class, take string and int input which are characters and length of the output String.
	The output String is permutation of the characters in the input String.

Problem 3: Pascal.java
	This class, take int input which is the height and the width of the pascal triangle.
	The output is Pascal triangle.

Problem 4: Triple.java, CachedPascal.java
	This class, is similar to the Pascal but this class is much faster. The reason that it faster
	because there is cache store in the class, whenever there is a calculation, the information is
	stored in the cache.	

Problem 5: Maze.java
	This class solve the maze problem, and print the right walkpath along with the maze